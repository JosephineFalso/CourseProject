import json
import csv

def lambda_handler(event, context):
    data = {}
    data['keywords'] = []
    with open('keywords.txt', newline='') as csvfile:
     csvreader = csv.reader(csvfile)
     for row in csvreader:
         data['keywords'].append(row)
    # TODO implement
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(data)
    }
