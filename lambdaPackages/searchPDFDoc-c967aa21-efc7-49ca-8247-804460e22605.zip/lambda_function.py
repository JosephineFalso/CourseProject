
import json
import boto3
import re
from urllib.parse import unquote_plus
import fitz

def lambda_handler(event, context):
    # TODO implement
    term=""
    if event:
     term = event["queryStringParameters"]["term"]
    if not term:
        term="precision"
    #print(term)
    # boto3 client
    s3 = boto3.client("s3")
    # retrieving object from S3
    fileObj = s3.get_object(Bucket="s3pdfbucket", Key="2915031.pdf")
    output = searchPDFTerm(fileObj, term)
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(output)
    }

## FUNCTION Usage 
# from pdfsearch import searchPDFTerm
# output = searchTerm(pdfFilePath,term)
# for ex: output = searchPDFTerm("../pdf/2915031.pdf", "precision") returns json
def searchPDFTerm(fileObj,term):
  print(term)    
  # reading botocore stream
  file_content = fileObj["Body"].read()
  url = "https://i-share-uiu.primo.exlibrisgroup.com/permalink/01CARLI_UIU/1ubbi2j/alma99839869412205899";
  # get number of pages
  
  pagenumbers = ""
  sequence = []
  data = {}
  data[term] = []
  
  
  # loading pdf from memory/stream
  with fitz.open(stream=file_content, filetype="pdf") as doc:
    # iterating through pdf file pages
    for page in doc:
      i = page.number    
      pdfText = page.get_text("text") 
      resSearch = re.search(term.lower(), pdfText.lower())
    
      if (resSearch):
        if (pagenumbers != ""):
         seqLen = len(sequence)   
         if (( seqLen != 0) and (sequence[seqLen-1] == i)):
             sequence.append(i+1)
         else:
              if (len(sequence) > 1):   
                 pagenumbers = pagenumbers + "-" + str(i)
                 sequence = []
                 sequence.append(i+1)
              else:   
                 pagenumbers = pagenumbers + "," +  str(i+1)
                 sequence = []
                 sequence.append(i+1)
        else:
         pagenumbers =  str(i+1)
         sequence.append(i+1)     
        #print("this is page " + str(i+1)) 
      else:
        if ((len(sequence) != 1) and (len(sequence) != 0)):   
            pagenumbers = pagenumbers + "-" + str(i)
        sequence = []
  data[term].append({
             'url': url,
             'pagenumbers': pagenumbers
        })      
  print(pagenumbers)
  return data



